/*
** EPITECH PROJECT, 2019
** my malloc
** File description:
** tarek
*/

#include <unistd.h>
#include <stdlib.h>

char *my_malloc_str(char *mem, int lenght)
{
    mem = malloc(sizeof(char) * lenght);

    for (int i = 0; i < lenght; i++)
        mem[i] = 0;
    return (mem);
}
