/*
** EPITECH PROJECT, 2019
** main
** File description:
** main
*/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

char *my_malloc_str(char *mem, int lenght);

int check_carac(char *parce, char carac)
{
    for (int a = 0; parce[a] != '\0'; a += 1)
        if (parce[a] == carac)
            return (1);
    return (0);
}

int lenght_tab(char *str, char *parce)
{
    int lenght = 0;
    int a = 0;

    for (; str[a]; a += 1) {
        if ((check_carac(parce, str[a]) && check_carac(parce, \
        str[a + 1]) == 0))
        lenght += 1;
    }
    return (lenght);
}

int set_index(char *str, char *parce, char **tab)
{
    int b = 0;

    tab[0] = my_malloc_str(tab[0], 100);
    tab[1] = my_malloc_str(tab[1], 1000);
    for (; str[b] && check_carac(parce, str[b]) == 0; b += 1)
        tab[0][b] = str[b];
    tab[0][b] = 0;
    return (b);
}

char **is_null(char *str)
{
    char **tab = malloc(sizeof(char *) * 3);
    tab[0] = my_malloc_str(tab[0], 100);
    tab[1] = NULL;
    for (int a = 0; str[a]; a += 1)
        tab[0][a] = str[a];
    return (tab);
}

char **my_str_to_word_array(char *str, char *parce)
{
    char **tab = malloc(sizeof(char *) * (lenght_tab(str, parce) + 3));
    if (lenght_tab(str, parce) == 0)
        return (is_null(str));
    int d = 0;
    int b = 0;

    tab[0] = my_malloc_str(tab[0], 1000);
    tab[1] = my_malloc_str(tab[1], 1000);
    for (; str[b] && check_carac(parce, str[b]); b += 1);
    for (int f = 0; str[b]; b += 1, f += 1) {
        for (; str[b] && check_carac(parce, str[b]); b += 1) {
            if ((check_carac(parce, str[b]) && check_carac(parce, str[b + 1]) \
            == 0) || !str[b]) {
            f = 0;
            d += 1;
            tab[d] = my_malloc_str(tab[d], 1000); }
        }
        tab[d][f] = str[b];
    }
    d = (tab[d] == 0) ? d : d + 1;
    tab[d] = NULL;
    return (tab);
}