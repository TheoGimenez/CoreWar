/*
** EPITECH PROJECT, 2018
** my_strncmp
** File description:
** tarek
*/

int my_strncmp(char const *s1, char const *s2, int n)
{
    int a = 0;

    while (s1[a] == s2[a] && s1[a] != n && s2[a] != n)
        a++;
    return (s1[a] - s2[a]);
}