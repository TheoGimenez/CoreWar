/*
** EPITECH PROJECT, 2019
** error_handling.c
** File description:
** error champions name comment
*/

#include "include/struct.h"

int is_exist(char cmd[16][5], var_t *var, int b)
{
    for (int a = 0; a < 16; a += 1)
        if (!my_strcmp(var->file[b], cmd[a]))
            return (1);
    return (0);
}

void check_instruction(char cmd[16][5], var_t *var)
{
    for (int a = 0; var->file[a]; a += 1)
        if (is_exist(cmd, var, a))
            return;
    if (var->file[0] != NULL && var->file[0][0] != 0)
        exit (84);
}