/*
** EPITECH PROJECT, 2019
** asm
** File description:
** asm
*/

#include "include/struct.h"

int my_strlen(char *str)
{
    int i = 0;

    for (; str[i]; i++);
    return (i);
}

long little_to_big(long a, int size)
{
    long b = 0;

    for (int i = 0; i < size; i++) {
        b *= 256;
        b += a % 256;
        a /= 256;
    }
    return (b);
}

void write_name(int fd, char *name, char *com, long size)
{
    int i = 0;
    char null = 0;
    long header = little_to_big(COREWAR_EXEC_MAGIC, 4);

    write(fd, &header, 4);
    for (; name[i]; i++)
        write(fd, name + i, 1);
    for (; i < PROG_NAME_LENGTH; i++)
        write(fd, "\0", 1);
    write(fd, &size, 8);
    for (i = 0; com[i]; i++)
        write(fd, com + i, 1);
    for (; i < COMMENT_LENGTH; i++)
        write(fd, "\0", 1);
    for (i = 16 - ((12 + PROG_NAME_LENGTH + COMMENT_LENGTH) % 16); i > 0; i--)
        write(fd, &null, 1);
}

label_t *find_labels(int fd, char *name, char *comment, char **cmd)
{
    label_t *label = malloc(sizeof(label_t));
    long size = 0;

    label[0].name = NULL;
    for (int i = 0; cmd[i]; i++) {
        if (cmd[i][my_strlen(cmd[i]) - 1] == LABEL_CHAR)
            label = add_label(label, size, cmd[i]);
        else if (!my_strcmp(cmd[i], "live") || !my_strcmp(cmd[i], "fork") ||
        !my_strcmp(cmd[i], "lfork") || !my_strcmp(cmd[i], "zjmp") ||
        cmd[i][0] == 'r')
            size++;
        else
            size += my_find_type(cmd[i]);
        if (!my_strcmp(cmd[i], "live"))
            size += 4 - DIR_SIZE;
    }
    write_name(fd, name, comment, little_to_big(size, 8));
    return (label);
}

void compile(char **cmd, char *n, char *comment, char *name)
{
    char *new = malloc(my_strlen(name) + 2);
    FILE *file;
    int fd;
    label_t *label = NULL;
    int val[3] = {0, 0, 0};

    for (int i = 0; i < my_strlen(name) - 1; i++)
        new[i] = name[i];
    new[my_strlen(name) - 1] = 'c';
    new[my_strlen(name)] = 'o';
    new[my_strlen(name) + 1] = 'r';
    file = fopen(new, "w");
    fclose(file);
    fd = open(new, O_WRONLY);
    free(new);
    label = find_labels(fd, n, comment, cmd);
    my_write_cmds(label, cmd, fd, val);
    close(fd);
    free(label);
}
