/*
** EPITECH PROJECT, 2019
** usage.c
** File description:
** usage.c
*/

#include "include/struct.h"

int help_usage(int ac, char **av)
{
    if (ac == 2 && !my_strcmp(av[1], "-h")) {
        write(1, "USAGE\n\t./asm file_name[.s]\n\nDESCRIPTION\n" \
        "\tfile_name\tfile in assembly language to be converted into " \
        "file_name.c, an \n\t\t\texecutable in the Virtual Machine.\n", 154);
        return (1);
    }
    if (ac == 2 && av[1][my_strlen(av[1]) - 1] != 's' && \
    av[1][my_strlen(av[1]) - 2] != '.' )
        exit (84);
    return (0);
}