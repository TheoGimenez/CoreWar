/*
** EPITECH PROJECT, 2019
** struct.h
** File description:
** struct.h
*/

#ifndef STRUCT_H_
#define STRUCT_H_
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string.h>
#include "../../op.h"

typedef struct var_s {
    char **file;
    char **tmp;
    char *name;
    char *comment;
} var_t;

typedef struct label_s {
    char *name;
    int place;
} label_t;

char **my_str_to_word_array(char *, char *);
char *my_malloc_str(char *, int);
char *my_calloc(int);
int my_strcmp(char const *, char const  *);
int help_usage(int, char **);
void remove_comm(char *str);
void compile(char **cmd, char *, char *, char *name);
char *get_str(char *str);
void remove_comm(char *str);
void get_file(char *str, var_t *var);
int get_index(char **tab, int d);
int cmp_comment(char *cmp, int b);
int cmp_name(char *cmp, int b);
int error_name_comm(char **tab);
void error_pos_name(var_t *var);
int my_strlen(char *str);
int is_exist(char cmd[16][5], var_t *var, int b);
void check_instruction(char cmd[16][5], var_t *var);
int my_strncmp(char const *s1, char const *s2, int n);
label_t *add_label(label_t *old, int size, char *name);
int my_find_type(char *cmd);
void my_write_cmds(label_t *label, char **cmd, int fd, int i[3]);
void write_val(char *val, int size, int fd, int *v[3]);
void write_cmd(char **cmd, char name[16][5], int *place[3], int fd);
void my_write(int fd, char *str, int size, int *i);
void free_all(var_t *var);
void error_lenght_name_com(var_t *var, char **tmp);

#endif
