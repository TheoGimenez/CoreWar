/*
** EPITECH PROJECT, 2019
** label
** File description:
** label
*/

#include "include/struct.h"

label_t *add_label(label_t *old, int size, char *name)
{
    int i = 0;
    label_t *new;

    for (; old[i].name; i++);
    new = malloc(sizeof(label_t) * (i + 2));
    for (int j = 0; j < i; j++)
        new[j] = old[j];
    free(old);
    new[i + 1].name = NULL;
    new[i].place = size;
    new[i].name = name;
    return (new);
}

int my_find_type(char *cmd)
{
    if (cmd[0] == DIRECT_CHAR)
        return (DIR_SIZE);
    if (cmd[0] > '9' && cmd[0] != LABEL_CHAR)
        return (2);
    return (IND_SIZE);
}

int my_labelcmp(char *str, char *label)
{
    int i = 0;

    for (; str[i] && label[i]; i++)
        if (str[i] != label[i])
            return (1);
    if (str[i] || label[i] != LABEL_CHAR)
        return (1);
    return (0);
}

void write_label(label_t *label, char *cmd, int *p[3], int fd)
{
    int size = IND_SIZE;
    int i = 0;
    int dif;
    char *val;

    (cmd[0] == LABEL_CHAR) ? size = DIR_SIZE : 0;
    (cmd[0] == LABEL_CHAR) ? cmd++ : 0;
    val = malloc(size);
    for (; my_labelcmp(cmd, label[i].name); i++);
    dif = (label[i].place > (*p)[2]) ? label[i].place - (*p)[2] : (*p)[2] -
    label[i].place - 1;
    for (int j = size - 1; j >= 0; j--) {
        val[j] = dif % 256;
        dif /= 256;
    }
    if (label[i].place < (*p)[2])
        for (int j = 0; j < size; j++)
            val[j] = (val[j]) ? val[j] * -1 : -1;
    my_write(fd, val, size, &(*p)[1]);
    free(val);
}

void my_write_cmds(label_t *label, char **cmd, int fd, int i[3])
{
    char cmp[16][5] = {"live", "ld", "st", "add", "sub", "and", "or", "xor",
    "zjmp", "ldi", "sti", "fork", "lld", "lldi", "lfork", "aff"};

    for (; cmd[*i]; (*i)++) {
        if (cmd[*i][0] == LABEL_CHAR || cmd[*i][1] == LABEL_CHAR)
            write_label(label, cmd[*i] + 1, &i, fd);
        else if (cmd[*i][0] == DIRECT_CHAR && cmd[*i][my_strlen(cmd[*i]) - 1]
        != LABEL_CHAR)
            write_val(cmd[*i] + 1, DIR_SIZE, fd, &i);
        if (cmd[*i][0] >= '0' && cmd[*i][0] <= '9' &&
        cmd[*i][my_strlen(cmd[*i]) - 1] != LABEL_CHAR)
            write_val(cmd[*i], IND_SIZE, fd, &i);
        if (cmd[*i][0] == 'r' && cmd[*i][my_strlen(cmd[*i]) - 1] != LABEL_CHAR)
            write_val(cmd[*i] + 1, 1, fd, &i);
        else if (cmd[*i][0] > '@' && cmd[*i][0] != DIRECT_CHAR && cmd[*i][0] !=
        LABEL_CHAR && cmd[*i][my_strlen(cmd[*i]) - 1] != LABEL_CHAR) {
            write_cmd(cmd, cmp, &i, fd);
            i[2] = i[1] - 1;
        }
    }
}
