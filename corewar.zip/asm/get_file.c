/*
** EPITECH PROJECT, 2019
** get_file
** File description:
** get_file_parse
*/

#include "include/struct.h"

int remove_cm(char *str)
{
    int d = 0;

    for (int a = 0; str[a]; a += 1) {
        if (str[a] == '"' && d != 4)
            d++;
        else if (d == 4)
            return (a);
    }
    return (0);
}

void free_all(var_t *var)
{
    for (int a = 0; var->file[a]; a += 1)
        free(var->file[a]);
    free(var->file);
}

void remove_comm(char *str)
{
    for (int a = 0; str[a]; a += 1)
        if (str[a] == COMMENT_CHAR)
            for (; str[a] != '\n' && str[a] != '\0'; a += 1)
                str[a] = ' ';
}

void error_file(char *buf, var_t *var, char *sep)
{
    char **tmp = my_str_to_word_array(buf, "\n");

    error_name_comm(tmp);
    error_lenght_name_com(var, tmp);
    var->tmp = my_str_to_word_array(buf, sep);
}

void get_file(char *str, var_t *var)
{
    int fd = open(str, O_RDONLY);
    char sep[5] = "\t \n";
    char buf[1000];
    int c = 0;

    if (fd == -1)
        exit (84);
    c = read(fd, buf, 1000);
    sep[3] = SEPARATOR_CHAR;
    sep[4] = 0;
    if (c == -1)
        exit (84);
    buf[c] = 0;
    remove_comm(buf);
    error_file(buf, var, sep);
    error_pos_name(var);
    var->file = my_str_to_word_array(buf + remove_cm(buf), sep);
    if (!my_strcmp(var->file[0], ".name"))
        var->file[0] = NULL;
    close(fd);
}