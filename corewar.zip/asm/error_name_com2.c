/*
** EPITECH PROJECT, 2019
** error_name_com
** File description:
** error_name_com2
*/

#include "include/struct.h"

void error_pos_name(var_t *var)
{
    int a = 0;

    if (my_strcmp(var->tmp[0], ".name") && var->tmp[1][0] != '"')
        exit (84);
    for (; var->tmp[a][my_strlen(var->tmp[a]) - 1] != '"'; a += 1);
    if (my_strcmp(var->tmp[a + 1], ".comment"))
        exit (84);
}

void error_lenght_name_com(var_t *var, char **tmp)
{
    var->name = get_str(tmp[get_index(tmp, 0)]);
    var->comment = get_str(tmp[get_index(tmp, 1)]);

    if (my_strlen(var->name) > PROG_NAME_LENGTH)
        exit (84);
    if (my_strlen(var->comment) > COMMENT_LENGTH)
        exit (84);
}