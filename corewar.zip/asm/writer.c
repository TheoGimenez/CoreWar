/*
** EPITECH PROJECT, 2019
** writer
** File description:
** writer
*/

#include "include/struct.h"

void my_write(int fd, char *str, int size, int *i)
{
    *i += size;
    write(fd, str, size);
}

void write_val(char *val, int size, int fd, int *v[3])
{
    int tmp;
    char ans[size];

    for (int i = 0; i < size; i++)
        ans[i] = 0;
    for (int i = 0; val[i]; i++) {
        tmp = 0;
        for (int j = size - 1; j >= 0; j--) {
            tmp += ans[j] * 10;
            ans[j] = tmp % 256;
            tmp /= 256;
        }
        tmp = val[i] - 48;
        for (int j = size - 1; j >= 0; j--) {
            tmp += ans[j];
            ans[j] = tmp % 256;
            tmp /= 256;
        }
    }
    my_write(fd, ans, size, &(*v)[1]);
}

int my_get_type(char c)
{
    if (c == DIRECT_CHAR)
        return (2);
    if (c == 'r')
        return (1);
    return (3);
}

void write_cmd(char **cmd, char name[16][5], int *place[3], int fd)
{
    char i = 1;
    char bin = 0;

    for (; my_strcmp(cmd[**place], name[i - 1]); i++);
    my_write(fd, &i, 1, &(*place)[1]);
    if (i == 1)
        for (int j = DIR_SIZE; j < 4; j++)
            my_write(fd, &bin, 1, &(*place)[1]);
    if (i == 1 || i == 9 || i == 12 || i == 15)
        return;
    bin = my_get_type(cmd[**place + 1][0]) * 64;
    if (i < 15)
        bin += my_get_type(cmd[**place + 2][0]) * 16;
    if (i < 15 && i != 13 && i > 3)
        bin += my_get_type(cmd[**place + 3][0]) * 4;
    my_write(fd, &bin, 1, &(*place)[1]);
}
