/*
** EPITECH PROJECT, 2019
** error_name_com
** File description:
** error_name_com
*/

#include "include/struct.h"

char *get_str(char *str)
{
    char *cpy = malloc(my_strlen(str));
    int d = 0;

    for (int a = 0; str[a]; a += 1) {
        if (str[a] == '"') {
            a += 1;
            for (; str[a] != 0 && str[a] != '"'; a += 1, d += 1)
                cpy[d] = str[a];
        }
    }
    if (d == 0)
        exit (84);
    cpy[d] = 0;
    return (cpy);
}

int cmp_comment(char *cmp, int b)
{
    char *c = COMMENT_CMD_STRING;
    int d = b;

    for (int a = 0; c[a]; a += 1, d += 1) {
        if (c[a] != cmp[d])
            return (0);
    }
    return (1);
}

int cmp_name(char *cmp, int b)
{
    char *c = NAME_CMD_STRING;
    int d = b;

    for (int a = 0; c[a]; a += 1, d += 1) {
        if (c[a] != cmp[d])
            return (0);
    }
    return (1);
}

int error_name_comm(char **tab)
{
    int n = 0;
    int c = 0;

    for (int a = 0; tab[a]; a += 1) {
        for (int b = 0; tab[a][b]; b += 1) {
            if (cmp_name(tab[a], b))
                n += 1;
            if (cmp_comment(tab[a], b))
                c += 1;
        }
    }
    if (n != 1 || c != 1)
        exit (84);
    return (0);
}

int get_index(char **tab, int d)
{
    for (int a = 0; tab[a]; a += 1) {
        for (int b = 0; tab[a][b]; b += 1) {
            if (cmp_name(tab[a], b) && d == 0)
                return (a);
            if (cmp_comment(tab[a], b) && d == 1)
                return (a);
        }
    }
    return (0);
}
