/*
** EPITECH PROJECT, 2019
** main.c
** File description:
** tarek
*/

#include "include/struct.h"

int main(int ac, char **av)
{
    var_t var;
    char cmd[16][5] = {"live", "ld", "st", "add", "sub", "and", "or", "xor", \
    "zjmp", "ldi", "sti", "fork", "lld", "lldi", "lfork", "aff"};
    if (help_usage(ac, av))
        return (0);
    get_file(av[1], &var);
    check_instruction(cmd, &var);
    compile(var.file, var.name, var.comment, av[1]);
    free_all(&var);
    return (0);
}
