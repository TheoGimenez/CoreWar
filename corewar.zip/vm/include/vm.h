/*
** EPITECH PROJECT, 2018
** vm.h
** File description:
** my personal .h for corewar project
*/

#ifndef VM_H_
#define VM_H_

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <limits.h>
#include "../../op.h"
#include "my.h"
#include "struct.h"
#include "utile.h"

void set_carry_to_zero(champion_t *);
int convert_bytes_to_int(vm_t *vm, int actual_index, int size);
void reverse_indian(char *, unsigned long);
int get_register(vm_t *, type_ptr_t *data, int src_size, champion_t *champ);
int get_direct(vm_t *, type_ptr_t *data, int src_size);
int get_indirect(vm_t *vm, type_ptr_t *data, int index[], int);
int get_indirect_scope(vm_t *vm, type_ptr_t *data, int index[], int);
int set_register(vm_t *vm, type_ptr_t *data, int arena_index, \
champion_t *champ);
int set_direct(vm_t *vm, type_ptr_t *data, int arena_index);
int set_indirect(vm_t *vm, type_ptr_t *data, int index[]);
int set_indirect_scope(vm_t *vm, type_ptr_t *data, int index[]);
int set_indirect_val_scope(vm_t *vm, type_ptr_t *data, int index[]);
int get_first_arg(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t *ptr_type);
int get_second_arg(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t *ptr_type);
int get_third_arg(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t *ptr_type);
int sti_second_arg(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t *ptr_type);
int sti_third_arg(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t *ptr_type);
void my_dump(vm_t *vm, int cycle);
int get_dump(char **av, vm_t *vm);
void cycle_cor(vm_t *vm);
int convert_bytes_to_int_bis(char *bytes, int size);
type_ptr_t init_type_ptr(void);
int get_first_arg_bis(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t *ptr_type);
int get_second_arg_bis(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t *ptr_type);
int get_third_arg_bis(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t *ptr_type);
void check_live_champ(vm_t *vm);
void check_live_champ_bis(vm_t *vm, champion_t *champ);
void add_cor(vm_t *vm, int arena_index, champion_t *champ);
void and_cor(vm_t *vm, int arena_index, champion_t *champ);
void or_cor(vm_t *vm, int arena_index, champion_t *champ);
void aff_cor(vm_t *vm, int arena_index, champion_t *champ);
void and_cor(vm_t *vm, int arena_index, champion_t *champ);
void fork_cor(vm_t *vm, int arena_index, champion_t *champ);
void ld_cor(vm_t *vm, int arena_index, champion_t *champ);
int init_vm(vm_t *vm, parm_champ_t *champ);
parm_champ_t *set_champ_agr(int ac, char **av);
int clone_champ(champion_t *pather, int pc);
void destroy_champ(champion_t *champ);
champion_t *get_champ(champion_t *champ, int champ_index);
int is_num(char *nbr);
int get_first_nbr(parm_champ_t *champ);
int my_champlen(parm_champ_t *champ);
void live_cor(vm_t *vm, int arena_index, champion_t * champ);
void ld_cor(vm_t *vm, int arena_index, champion_t *champ);
void st_cor(vm_t *vm, int arena_index, champion_t * champ);
void add_cor(vm_t *vm, int arena_index, champion_t *champ);
void sub_cor(vm_t *vm, int arena_index, champion_t * champ);
void and_cor(vm_t *vm, int arena_index, champion_t *champ);
void or_cor(vm_t *vm, int arena_index, champion_t * champ);
void xor_cor(vm_t *vm, int arena_index, champion_t * champ);
void zjump_cor(vm_t *vm, int arena_index, champion_t * champ);
void ldi_cor(vm_t *vm, int arena_index, champion_t * champ);
void sti_cor(vm_t *vm, int arena_index, champion_t * champ);
void fork_cor(vm_t *vm, int arena_index, champion_t * champ);
void lld_cor(vm_t *vm, int arena_index, champion_t * champ);
void lldi_cor(vm_t *vm, int arena_index, champion_t * champ);
void lfork_cor(vm_t *vm, int arena_index, champion_t * champ);
void aff_cor(vm_t *vm, int arena_index, champion_t * champ);

#endif
