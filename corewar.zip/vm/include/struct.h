/*
** EPITECH PROJECT, 2019
** struct.h
** File description:
** virtual machine's structs
*/

#ifndef STRUCT_H_
#define STRUCT_H_

typedef struct parm_champ_s parm_champ_t;
typedef struct champion_s champion_t;
typedef struct vm_s vm_t;
typedef struct type_ptr_s type_ptr_t;
typedef void(*instruction)(vm_t *, int, champion_t *);

struct champion_s
{
    char name[PROG_NAME_LENGTH];
    int cham_nb;
    unsigned char reg[REG_NUMBER][REG_SIZE];
    int pc;
    char carry;
    int cycle_to_die;
    int live;
    champion_t *next;
    champion_t *prev;
};

struct vm_s
{
    champion_t **champ;
    char dump;
    int cycle;
    int champ_nbr;
    unsigned char arena[MEM_SIZE];
    instruction cmd[16];
};

struct type_ptr_s
{
    unsigned char *src;
    int src_size;
    int read_size;
    unsigned char reg_bytes[REG_SIZE];
    unsigned char dir_bytes[DIR_SIZE];
    unsigned char ind_bytes[IND_SIZE];
};

struct parm_champ_s
{
    int nbr;
    int address;
    char *path;
};

typedef union convert_s
{
    int nbr;
    char bytes[IND_SIZE > DIR_SIZE ? IND_SIZE : DIR_SIZE];
} convert_t;

#endif
