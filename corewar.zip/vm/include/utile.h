/*
** EPITECH PROJECT, 2018
** utile.h
** File description:
** my personal .h file
*/

#ifndef UTILE_H_
#define UTILE_H_

#define UNUSED __attribute__((unused))
#define CONST __attribute__((const))
#define VOID __attribute__((noreturn))

#define LIVE 1
#define LD 2
#define ST 3
#define ADD 4
#define SUB 5
#define AND 6
#define OR 7
#define XOR 8
#define ZJMP 9
#define LDI 10
#define STI 11
#define FORK 12
#define LLD 13
#define LLDI 14
#define LFORK 15
#define AFF 16

#define IS_REG(byte, arg) (((unsigned char)(byte << (arg * 2)) >> 6) == 1)
#define IS_DIR(byte, arg) (((unsigned char)(byte << (arg * 2)) >> 6) == 2)
#define IS_IND(byte, arg) (((unsigned char)(byte << (arg * 2)) >> 6) == 3)

#define GET_ARG1(X) ((X & 0xC0) >> 6)
#define GET_ARG2(X) ((X & 0x30) >> 4)
#define GET_ARG3(X) ((X & 0x0C) >> 2)

#endif
