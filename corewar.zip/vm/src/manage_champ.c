/*
** EPITECH PROJECT, 2019
** init_struct.c
** File description:
** init struct file
*/

#include "vm.h"

int clone_champ(champion_t *pather, int pc)
{
    champion_t *new;

    if (pather)
        return (-1);
    new = malloc(sizeof(champion_t));
    for (int index = 0; index != PROG_NAME_LENGTH; index++)
        new->name[index] = pather->name[index];
    for (int index = 0; index != REG_NUMBER; index++)
        for (int index_bis = 0; index_bis != REG_SIZE; index_bis++)
            new->reg[index][index_bis] = pather->reg[index][index_bis];
    for (; pather->next; pather = pather->next);
    new->pc = pc;
    new->carry = 1;
    new->cycle_to_die = pather->cycle_to_die;
    new->live = pather->live;
    new->next = NULL;
    new->prev = pather;
    pather->next = new;
    return (0);
}

void destroy_champ(champion_t *champ)
{
    if (!champ)
        return;
    if (champ->prev)
        champ->prev->next = champ->next;
    if (champ->next)
        champ->next->prev = champ->prev;
    free(champ);
}

champion_t *get_champ(champion_t *champ, int champ_index)
{
    int index = 0;
    champion_t *champ_find = champ;

    if (!champ)
        return (NULL);
    for (; champ_find->next && champ_index != index; \
    champ_find = champ_find->next)
        index++;
    if (index == champ_index)
        return (champ_find);
    else
        return (NULL);
}

void check_live_champ_bis(vm_t *vm, champion_t *champ)
{
    if (!champ)
        return;
    if (champ->live <= 0)
        destroy_champ(champ);
    else {
        champ->live--;
        champ->cycle_to_die = vm->cycle;
    }
}

void check_live_champ(vm_t *vm)
{
    for (int index = 0; vm->champ[index]; index++) {
        for (champion_t *champ_index = vm->champ[index]; champ_index && \
        champ_index->next; champ_index = champ_index->next)
            check_live_champ_bis(vm, champ_index);
    }
}
