/*
** EPITECH PROJECT, 2019
** init_struct.c
** File description:
** init struct file
*/

#include "vm.h"

void init_struct_cmd(vm_t *vm)
{
    instruction cmd_tmp[16] = {&live_cor, &ld_cor, &st_cor, \
    &add_cor, &sub_cor, &and_cor, &or_cor, &xor_cor, &zjump_cor, &ldi_cor, \
    &sti_cor, &fork_cor, &lld_cor, &lldi_cor, &lfork_cor, &aff_cor};

    for (int index = 0; index != 16; index++)
        vm->cmd[index] = cmd_tmp[index];
}

type_ptr_t get_champ_bytes(char *path)
{
    type_ptr_t champ;
    int fd = open(path, O_RDONLY);
    char bytes[MEM_SIZE + 1];

    champ.src = (unsigned char [4]){0, 0, 0, 0};
    champ.src_size = -1;
    if (fd < 0)
        return (champ);
    champ.src_size = read(fd, bytes, sizeof(bytes));
    if (champ.src_size < 0)
        return (champ);
    champ.src = malloc(sizeof(char) * (champ.src_size + \
    PROG_NAME_LENGTH + COMMENT_LENGTH + 10));
    for (int index = 0; index != champ.src_size; index++)
        champ.src[index] = bytes[index];
    close(fd);
    return (champ);
}

int init_champ_bis(vm_t *vm, int champ_nb)
{
    vm->champ[champ_nb]->carry = 1;
    vm->champ[champ_nb]->cycle_to_die = CYCLE_TO_DIE;
    vm->champ[champ_nb]->live = 1;
    vm->champ[champ_nb]->next = NULL;
    vm->champ[champ_nb]->prev = NULL;
    for (int index = 0; index != REG_NUMBER; index++)
        for (int index_bis = 0; index_bis != REG_SIZE; index_bis++)
            vm->champ[champ_nb]->reg[index][index_bis] = 0;
    my_ito_str(champ_nb, (char *) vm->champ[champ_nb]->reg[0]);
    return (0);
}

int init_champ(vm_t *vm, char *path, int *index1)
{
    type_ptr_t bytes = get_champ_bytes(path);
    convert_t tmp;

    tmp.nbr = *((unsigned int *)bytes.src);
    reverse_indian(tmp.bytes, 4);
    vm->champ[index1[2]] = malloc(sizeof(champion_t));
    if (bytes.src_size == -1 || bytes.src_size < PROG_NAME_LENGTH + \
    COMMENT_LENGTH + 4 || tmp.nbr != COREWAR_EXEC_MAGIC || index1[2] < 0)
        return (write(2, "Invalid arg\n", 12) - 13);
    vm->champ[index1[2]]->cham_nb = index1[2];
    vm->champ[index1[2]]->pc = index1[0];
    for (int index = 0; index != PROG_NAME_LENGTH; index++)
        vm->champ[index1[2]]->name[index] = bytes.src[index + 4];
    for (int index = 0; PROG_NAME_LENGTH + COMMENT_LENGTH + 12 + \
    index < bytes.src_size; index++)
        vm->arena[(index + index1[0]) % MEM_SIZE] = \
        bytes.src[index + PROG_NAME_LENGTH + COMMENT_LENGTH + 12 + 4];
    return (init_champ_bis(vm, index1[2]));
}

int init_vm(vm_t *vm, parm_champ_t *champ)
{
    vm->champ_nbr = my_champlen(champ);
    if (vm->champ_nbr < 2)
        return (-1);
    vm->champ = malloc(sizeof(champion_t *) * (vm->champ_nbr + 4));
    for (int index = 0; index != vm->champ_nbr + 2; index++)
        vm->champ[index] = NULL;
    vm->cycle = CYCLE_TO_DIE;
    for (int index = 0; index != MEM_SIZE; index++)
        vm->arena[index] = 0;
    for (int index = 0; index != vm->champ_nbr; index++)
        if (init_champ(vm, champ[index].path, \
        (int [3]){champ[index].address, champ[index].nbr, index}) == -1)
            return (-1);
    init_struct_cmd(vm);
    return (0);
}
