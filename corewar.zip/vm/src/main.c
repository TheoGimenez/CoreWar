/*
** EPITECH PROJECT, 2019
** main.c
** File description:
** main file
*/

#include "vm.h"

int my_help(int ac, char **av)
{
    int test = 0;

    for (int index = 1; index != ac; index++)
        test = (!my_strcmp(av[index], "-h")) ? 1 : test;
    if (!test)
        return (0);
    write(1, "USAGE\n\t\t./corewar [-dump nbr_cycle] [[-n prog_number", 52);
    write(1, "] [-a load_address] prog_name] ...\n\nDESCRIPTION\n\t\t", 50);
    write(1, "-dump nbr_cycle\tdumps the memory after the nbr_cycle execution" \
    " (if the round isn't \n\t\t\t\talready over) with the following format:" \
    "  32 bytes/line in\n\t\t\t\thexadecimal (A0BCDEFE1DD3...)\n", 181);
    write(1, "\t\t-n prog_number\tsets the next program's number.  By " \
    "default, the first free number\n\t\t\t\tin the parameter order\n", 111);
    write(1, "\t\t-a load_addresssets the next program's loading address.  " \
    "When no address is\n\t\t\t\tspecified, optimize the addresses so that " \
    "the processes are as far\n\t\t\t\taway from each other as possible.  The" \
    " addresses are MEM_SIZE modulo.\n", 223);
    return (1);
}

int main(int ac, char **av)
{
    vm_t vm;
    int dump = get_dump(av, &vm);

    if (dump == 1) {
        ac -= 2;
        av += 2;
    }
    if (my_help(ac, av))
        return (0);
    if (dump == -1 || init_vm(&vm, set_champ_agr(ac, av)) == -1)
        return (84);
    cycle_cor(&vm);
    free(vm.champ);
    return (0);
}
