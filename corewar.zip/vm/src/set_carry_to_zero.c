/*
** EPITECH PROJECT, 2019
** set_carry_to_zero.c
** File description:
** set carry flags to zero.
*/

#include "vm.h"

void set_carry_to_zero(champion_t *champion)
{
    champion->carry = 0;
    champion->pc += 1;
}
