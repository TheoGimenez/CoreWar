/*
** EPITECH PROJECT, 2019
** cycle.c
** File description:
** cycle file
*/

#include "vm.h"

void exec_cmd_cor(UNUSED vm_t *vm, champion_t *champ)
{
    if (!champ)
        return;
    if (vm->arena[champ->pc % MEM_SIZE] > 16 || \
    vm->arena[champ->pc % MEM_SIZE] == 0) {
        champ->pc++;
        return;
    }
    vm->cmd[vm->arena[champ->pc % MEM_SIZE] - 1](vm, champ->pc, champ);
    champ->pc = champ->pc % MEM_SIZE;
}

int check_win_champ(vm_t *vm)
{
    int nbr = 0;

    for (int index = 0; index < vm->champ_nbr; index++) {
        if (vm->champ[index])
            nbr++;
    }
    if (nbr > 1)
        return (1);
    return (0);
}

int get_champ_nbr_bis(champion_t *champ)
{
    int nbr = 0;

    for (champion_t *champ_tmp = champ; champ_tmp; champ_tmp = champ_tmp->next)
        nbr++;
    return (nbr);
}

void cycle_cor_bis(vm_t *vm, int cycle_loop)
{
    int champ_nbr = 0;

    for (int index = 0; index != vm->champ_nbr; index++) {
        champ_nbr = get_champ_nbr_bis(vm->champ[index]);
        if (vm->champ[index] && champ_nbr != 0)
            exec_cmd_cor(vm, get_champ(vm->champ[index], \
            cycle_loop % champ_nbr));
    }
}

void cycle_cor(vm_t *vm)
{
    while (vm->cycle > 0 && check_win_champ(vm)) {
        for (int cycle_loop = 0; cycle_loop < vm->cycle; cycle_loop++) {
            my_dump(vm, cycle_loop);
            cycle_cor_bis(vm, cycle_loop);
        }
        vm->cycle -= CYCLE_DELTA;
        check_live_champ(vm);
    }
    for (int index = 0; index < vm->champ_nbr; index++)
        if (vm->champ[index]) {
            write(1, "The player ", 11);
            my_put_nbr(vm->champ[index]->cham_nb);
            write(1, "(", 1);
            write(1, vm->champ[index]->name, my_strlen(vm->champ[index]->name));
            write(1, ") has won.\n", 11);
            return;
        }
}
