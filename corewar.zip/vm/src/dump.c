/*
** EPITECH PROJECT, 2019
** dump.c
** File description:
** dump file
*/

#include "vm.h"

void my_dump(vm_t *vm, int cycle)
{
    if (vm->dump == 0 || cycle % vm->dump != 0)
        return;
    for (int index = 0; index != MEM_SIZE; index++) {
        if (index % 32 == 0 && index != 0)
            write(1, "\n", 1);
        else if (index != 0)
            write(1, " ", 1);
        if ((unsigned char)vm->arena[index] < 16)
            write(1, "0", 1);
        my_putnbr_base((unsigned char)vm->arena[index], "0123456789ABCDEF");
    }
    write(1, "\n", 1);
}

int get_dump(char **av, vm_t *vm)
{
    vm->dump = 0;
    if (av[1] && !my_strcmp(av[1], "-dump") && !is_num(av[2]))
        return (write(2, "Invalid arg\n", 12) - 13);
    else if (av[1] && !my_strcmp(av[1], "-dump")) {
        vm->dump = my_getnbr(av[2]);
        return (1);
    }
    return (0);
}
