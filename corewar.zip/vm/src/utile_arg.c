/*
** EPITECH PROJECT, 2019
** utile_arg.c
** File description:
** utile arg file
*/

#include "vm.h"

int is_num(char *nbr)
{
    int index = 0;

    if (!nbr)
        return (0);
    for (; nbr[index] >= '0' && nbr[index] <= '9'; index++);
    return (!nbr[index]);
}

int get_first_nbr(parm_champ_t *champ)
{
    int test = 1;
    int nbr = 0;

    for (; test; nbr++) {
        test = 0;
        for (int index = 0; index != 4; index++)
            test = (nbr == champ[index].nbr) ? 1 : test;
        if (!test)
            break;
    }
    return (nbr);
}

int my_champlen(parm_champ_t *champ)
{
    int index = 0;

    if (!champ)
        return (0);
    while (champ[++index].path && index < 4);
    return (index);
}
