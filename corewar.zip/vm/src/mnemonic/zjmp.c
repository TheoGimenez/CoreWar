/*
** EPITECH PROJECT, 2019
** zjmp.c
** File description:
** zjmp file
*/

#include "vm.h"

void zjump_cor(vm_t *vm, int arena_index, champion_t *champ)
{
    type_ptr_t tmp = init_type_ptr();

    arena_index++;
    champ->cycle_to_die -= op_tab[ZJMP].code;
    for (int index = arena_index; index != arena_index + IND_SIZE; index++)
        tmp.ind_bytes[index - arena_index] = vm->arena[index % MEM_SIZE];
    tmp.src = tmp.ind_bytes;
    champ->pc += convert_bytes_to_int_bis((char *)tmp.src, IND_SIZE);
}
