/*
** EPITECH PROJECT, 2019
** sti.c
** File description:
** sti file
*/

#include "vm.h"

void sti_add(type_ptr_t *ptr_type)
{
    static int ret = 0;

    for (int i = REG_SIZE - 1, j = ptr_type[1].src_size - 1, \
    k = ptr_type[2].src_size - 1; i > -1; --i, --j, --k) {
        ptr_type[3].src[i] = (j > -1 ? ptr_type[1].src[i] : 0) + \
        (k > -1 ? ptr_type[2].src[i] : 0) + ret;
        if ((j > -1 ? ptr_type[1].src[i] : 0) + \
        (k > -1 ? ptr_type[2].src[i] : 0) + ret > 0xff)
            ret = 1;
        else
            ret = 0;
    }
    if (ret)
        sti_add(ptr_type);
}

void sti_cor(vm_t *vm, int arena_index, champion_t *champ)
{
    unsigned char flag = vm->arena[(arena_index + 1) % MEM_SIZE];
    type_ptr_t type[4];

    champ->cycle_to_die -= op_tab[STI].code;
    if ((flag & 0xC3) != 0x40 || (flag & 0x30) == 0x30 || (flag & 0x0C) == 0x03)
        return (set_carry_to_zero(champ));
    if (!get_register(vm, &type[0], arena_index + 2, champ) || \
    !sti_second_arg(vm, arena_index, champ, type) || \
    !sti_third_arg(vm, arena_index, champ, type))
        return (set_carry_to_zero(champ));
    my_memset(type[3].reg_bytes, 0, REG_SIZE);
    type[3].src = type[3].reg_bytes;
    type[3].src_size = REG_SIZE;
    sti_add(type);
    if (!set_indirect_val_scope(vm, &type[0], (int []) \
    {convert_bytes_to_int_bis((char *) type[3].src, REG_SIZE), arena_index}))
        return (set_carry_to_zero(champ));
    champ->carry = 1;
    champ->pc = \
    (champ->pc + 2 + 1 + type[1].read_size + type[2].read_size) % MEM_SIZE;
}
