/*
** EPITECH PROJECT, 2019
** and.c
** File description:
** performs binary AND between the two parameters and stores into the third one
*/

#include "vm.h"

void and_cor(vm_t *vm, int arena_index, champion_t *champ)
{
    unsigned char flag = vm->arena[(arena_index + 1) % MEM_SIZE];
    type_ptr_t ptr_type[3];

    champ->cycle_to_die -= op_tab[AND].code;
    if ((flag & 0xF0) == 0x80  || (flag & 0x0C) != 4 || flag & 0x03)
        return (set_carry_to_zero(champ));
    if (!get_first_arg(vm, arena_index, champ, ptr_type) || \
    !get_second_arg(vm, arena_index, champ, ptr_type) || \
    !get_register(vm, &ptr_type[2], \
    arena_index + 2 + ptr_type[0].read_size + ptr_type[1].read_size, champ))
        return (set_carry_to_zero(champ));
    my_memset(ptr_type[2].src, 0, REG_SIZE);
    for (int i = 0; i != REG_SIZE; ++i)
        ptr_type[2].src[i] = ptr_type[0].src[i] & ptr_type[1].src[i];
    champ->carry = 1;
    champ->pc += 2 + ptr_type[0].read_size + ptr_type[1].read_size + \
    ptr_type[2].read_size;
}
