/*
** EPITECH PROJECT, 2019
** aff.c
** File description:
** displays on the standard output character ASCII of the register
*/

#include "vm.h"

void aff_cor(vm_t *vm, int arena_index, champion_t *champ)
{
    int reg_index = vm->arena[(arena_index + 1) % MEM_SIZE];
    char tmp;

    champ->cycle_to_die -= op_tab[AFF].code;
    for (int index = 0; index != REG_SIZE; ++index) {
        tmp = champ->reg[reg_index][index] % 256;
        write(1, &tmp, 1);
    }
    champ->pc += 2;
}
