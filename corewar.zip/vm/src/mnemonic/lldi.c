/*
** EPITECH PROJECT, 2019
** lldi.c
** File description:
** lldi file
*/

#include "vm.h"

void lldi_cor(vm_t *vm, int arena_index, champion_t *champ)
{
    unsigned char flag = vm->arena[(arena_index + 1) % MEM_SIZE];
    type_ptr_t ptr_type[3];
    int index = arena_index;

    champ->cycle_to_die -= op_tab[LLDI].code;
    if (GET_ARG1(flag) < 2 || GET_ARG2(flag) < 2 || GET_ARG2(flag) != 1)
        return (set_carry_to_zero(champ));
    if (!get_first_arg_bis(vm, arena_index, champ, ptr_type) || \
    !get_second_arg_bis(vm, arena_index, champ, ptr_type) || \
    !get_register(vm, &ptr_type[2], arena_index + 2 + \
    ptr_type[0].read_size + ptr_type[1].read_size, champ))
        return (set_carry_to_zero(champ));
    index = convert_bytes_to_int_bis((char *)ptr_type[0].src, \
    ptr_type[0].src_size) + convert_bytes_to_int_bis((char *)ptr_type[1].src, \
    ptr_type[1].src_size);
    if (set_register(vm, &ptr_type[2], index, champ))
        return (set_carry_to_zero(champ));
    champ->carry = 1;
    champ->pc += 2 + ptr_type[0].read_size + ptr_type[1].read_size + \
    ptr_type[2].read_size;
}
