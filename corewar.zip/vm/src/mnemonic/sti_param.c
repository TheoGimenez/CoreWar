/*
** EPITECH PROJECT, 2019
** aff.c
** File description:
** displays on the standard output character ASCII of the register
*/

#include "vm.h"

int sti_get_direct(vm_t *vm, type_ptr_t *data, int src_size)
{
    int src_index = 4 - 1;

    data->src_size = 4;
    data->read_size = 2;
    src_size += src_size < 0 ? 0 : MEM_SIZE;
    for (int read_index = 2 - 1; read_index > -1 && src_index > -1; \
    --read_index, --src_index)
        data->dir_bytes[src_index] = \
        vm->arena[(read_index + src_size) % MEM_SIZE];
    while (src_index > -1)
        data->dir_bytes[src_index--] = 0;
    data->src = data->dir_bytes;
    return (2);
}

int sti_second_arg(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t * ptr_type)
{
    unsigned char arg2 = GET_ARG2(vm->arena[(arena_index + 1) % MEM_SIZE]);

    if (arg2 == 1 && !get_register(vm, &ptr_type[1], \
    arena_index + 2 + ptr_type[0].read_size, champ))
        return (0);
    else if (arg2 == 2 && !sti_get_direct(vm, &ptr_type[1], \
    arena_index + 2 + ptr_type[0].read_size))
        return (0);
    return (1);
}

int sti_third_arg(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t * ptr_type)
{
    unsigned char arg3 = GET_ARG3(vm->arena[(arena_index + 1) % MEM_SIZE]);

    if (arg3 == 1 && !get_register(vm, &ptr_type[2], \
    arena_index + 2 + ptr_type[0].read_size + ptr_type[1].read_size, champ))
        return (0);
    else if (arg3 == 2 && !sti_get_direct(vm, &ptr_type[2], \
    arena_index + 2 + ptr_type[0].read_size + ptr_type[1].read_size))
        return (0);
    return (1);
}
