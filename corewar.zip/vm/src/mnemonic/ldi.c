/*
** EPITECH PROJECT, 2019
** ldi.c
** File description:
** ldi file
*/

#include "vm.h"

int ldi_indirect_scope(vm_t *vm, type_ptr_t *data, int index[], int read_size)
{
    int indirect_index = index[0] % IDX_MOD;

    int tmp_index = 0;
    int src_index = REG_SIZE - 1;
    data->src_size = read_size;
    data->read_size = IND_SIZE;
    for (int read_index = read_size - 1; read_index > -1 && src_index > -1; \
    --read_index, --src_index) {
        tmp_index = ((index[1] + indirect_index + read_index) % MEM_SIZE);
        tmp_index += (tmp_index < 0) ? MEM_SIZE : 0;
        data->reg_bytes[src_index] = vm->arena[tmp_index];
    }
    while (src_index > -1)
        data->reg_bytes[src_index] = 0;
    data->src = data->reg_bytes;
    return (read_size);
}

void ldi_add(type_ptr_t *ptr_type)
{
    static int ret = 0;

    for (int i = REG_SIZE - 1, j = ptr_type[0].src_size - 1, \
    k = ptr_type[1].src_size - 1; i > -1; --i, --j, --k) {
        ptr_type[3].src[i] = (j > -1 ? ptr_type[0].src[i] : 0) + \
        (k > -1 ? ptr_type[1].src[i] : 0) + ret;
        if ((j > -1 ? ptr_type[0].src[i] : 0) + \
        (k > -1 ? ptr_type[1].src[i] : 0) + ret > 0xff)
            ret = 1;
        else
            ret = 0;
    }
    if (ret)
        ldi_add(ptr_type);
}

void ldi_cor_bis(vm_t *vm, int arena_index, type_ptr_t *ptr_type)
{
    my_memset(ptr_type[3].reg_bytes, 0, REG_SIZE);
    ptr_type[3].src = ptr_type[3].reg_bytes;
    ptr_type[3].src_size = REG_SIZE;
    ldi_add(ptr_type);
    ldi_indirect_scope(vm, &ptr_type[4], \
    (int []) {convert_bytes_to_int_bis((char *) ptr_type[3].src, \
    ptr_type[3].src_size) + arena_index, arena_index}, REG_SIZE);
    my_memcpy(ptr_type[2].src, ptr_type[4].src, REG_SIZE);
}

void ldi_cor(vm_t *vm, int arena_index, champion_t *champ)
{
    unsigned char flag = vm->arena[(arena_index + 1) % MEM_SIZE];
    type_ptr_t ptr_type[5];

    champ->cycle_to_die -= op_tab[LDI].code;
    if (GET_ARG1(flag) == 1 || GET_ARG2(flag) == 1 || GET_ARG3(flag) != 1)
        return (set_carry_to_zero(champ));
    if (!get_first_arg(vm, arena_index, champ, ptr_type) || \
    !get_second_arg(vm, arena_index, champ, ptr_type) || \
    !get_register(vm, &ptr_type[2], arena_index + 2 + \
    ptr_type[0].read_size + ptr_type[1].read_size, champ))
        return (set_carry_to_zero(champ));
    ldi_cor_bis(vm, arena_index, ptr_type);
    champ->carry = 1;
    champ->pc += 2 + ptr_type[0].read_size + ptr_type[1].read_size + \
    ptr_type[2].read_size;
}
