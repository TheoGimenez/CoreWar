/*
** EPITECH PROJECT, 2019
** add.c
** File description:
** adds the content of the first two param and puts the sum to the third one
*/

#include "vm.h"

void add_loop(type_ptr_t *ptr_type)
{
    static int ret = 0;

    for (int i = REG_SIZE - 1; i > -1; --i) {
        ptr_type[2].src[i] = ptr_type[0].src[i] + ptr_type[1].src[i] + ret;
        ret = (ptr_type[0].src[i] + ptr_type[1].src[i] + ret) > 0xff ? 1 : 0;
    }
    if (ret)
        add_loop(ptr_type);
}

void add_cor(vm_t *vm, int arena_index, champion_t *champ)
{
    unsigned char flag = vm->arena[(arena_index + 1) % MEM_SIZE];
    type_ptr_t ptr_type[3];

    champ->cycle_to_die -= op_tab[ADD].code;
    if (flag != 0x54)
        return (set_carry_to_zero(champ));
    if (!get_register(vm, &ptr_type[0], arena_index + 2, champ))
        return (set_carry_to_zero(champ));
    if (!get_register(vm, &ptr_type[1], arena_index + 2 + 1, champ))
        return (set_carry_to_zero(champ));
    if (!get_register(vm, &ptr_type[2], arena_index + 2 + 1 * 2, champ))
        return (set_carry_to_zero(champ));
    my_memset(ptr_type[2].src, 0, REG_SIZE);
    add_loop((type_ptr_t *) ptr_type);
    champ->carry = 1;
    champ->pc += 2 + 1 * 3;
}
