/*
** EPITECH PROJECT, 2019
** fork.c
** File description:
** fork file
*/

#include "vm.h"

void fork_cor(vm_t *vm, int arena_index, champion_t *champ)
{
    type_ptr_t tmp = init_type_ptr();

    champ->cycle_to_die -= op_tab[FORK].code;
    if (!get_indirect_scope(vm, &tmp, \
    (int []) {arena_index + 1, arena_index}, REG_SIZE)) {
        champ->pc += 1;
        return;
    }
    champ->pc += 1;
    reverse_indian((char *)tmp.src, tmp.src_size);
    clone_champ(champ, convert_bytes_to_int_bis((char *)tmp.src, tmp.src_size));
    champ->pc += IND_SIZE;
}
