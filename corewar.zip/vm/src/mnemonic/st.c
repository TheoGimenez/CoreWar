/*
** EPITECH PROJECT, 2019
** st.c
** File description:
** stores first param’s val (a register) into the second (a register or number).
*/

#include "vm.h"

void st_cor(vm_t *vm, int arena_index, champion_t *champ)
{
    unsigned char flag = vm->arena[(arena_index + 1) % MEM_SIZE];
    type_ptr_t ptr_type[2];

    champ->cycle_to_die -= op_tab[ST].code;
    if ((flag & 0xCF) != 0x40 || (flag & 0x30) == 0x20)
        return (set_carry_to_zero(champ));
    if (!get_register(vm, &ptr_type[0], arena_index + 2, champ) || \
    !get_second_arg(vm, arena_index, champ, ptr_type))
        return (set_carry_to_zero(champ));
    if ((flag & 0x30) == 0x10) {
        my_memcpy(ptr_type[1].src, ptr_type[0].src, ptr_type[0].src_size);
    } else if ((flag & 0x30) == 0x30)
        if (!set_indirect_scope(vm, &ptr_type[0], \
        (int []) {arena_index + 2 + 1, arena_index}))
            return (set_carry_to_zero(champ));
    champ->carry = 1;
    champ->pc += 2 + 1 + ((flag & 0x30) == 0x30 ? IND_SIZE : 1);
}
