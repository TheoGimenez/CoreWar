/*
** EPITECH PROJECT, 2019
** live.c
** File description:
** indicates that the player is alive.
*/

#include "vm.h"

void live_cor(vm_t *vm, int arena_index, champion_t *champ)
{
    unsigned char bytes[4];

    champ->cycle_to_die -= op_tab[LIVE].code;
    for (int i = 0; i != 4; ++i)
        bytes[3 - i] = vm->arena[(arena_index + i + 1) % MEM_SIZE];
    write(1, "The player ", 11);
    my_put_nbr(*((int *)bytes));
    write(1, "(", 1);
    write(1, champ->name, \
    my_strlen(champ->name));
    write(1, ") is alive.\n", 12);
    champ->pc += 5;
    if (champ->live + 1 > NBR_LIVE)
        vm->cycle += 1;
    else
        champ->live += 1;
}
