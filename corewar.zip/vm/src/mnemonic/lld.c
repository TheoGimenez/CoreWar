/*
** EPITECH PROJECT, 2019
** lld.c
** File description:
** lld file
*/

#include "vm.h"

void lld_cor(vm_t *vm, int arena_index, champion_t *champ)
{
    unsigned char flag = vm->arena[(arena_index + 1) % MEM_SIZE];
    type_ptr_t ptr_type[2];

    champ->cycle_to_die -= op_tab[LLD].code;
    if (GET_ARG2(flag) != 1 || !GET_ARG1(flag))
        return (set_carry_to_zero(champ));
    if (!get_first_arg_bis(vm, arena_index, champ, ptr_type) || \
    !get_register(vm, &ptr_type[1], \
    arena_index + 2 + ptr_type[0].read_size, champ))
        return (set_carry_to_zero(champ));
    my_memcpy(ptr_type[1].src, ptr_type[0].src, REG_SIZE);
    champ->carry = 1;
    champ->pc += 2 + ptr_type[0].read_size + ptr_type[1].read_size;
}
