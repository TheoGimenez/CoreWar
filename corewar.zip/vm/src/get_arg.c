/*
** EPITECH PROJECT, 2019
** get_arg.c
** File description:
** get arg file
*/

#include "vm.h"

int get_flag_arg(char **av, int i, parm_champ_t *champ, int *test)
{
    int rtn = 0;

    if (!my_strcmp(av[i], "-n") && is_num(av[i + 1]) && champ->nbr == -1) {
        rtn = 1;
        champ->nbr = (unsigned int)my_getnbr(av[i + 1]);
    } else if (!my_strcmp(av[i], "-n"))
        *test = -1;
    if (!my_strcmp(av[i], "-a") && is_num(av[i + 1]) && champ->address == -1) {
        rtn = 1;
        champ->address = (unsigned int)my_getnbr(av[i + 1]);
    } else if (!my_strcmp(av[i], "-a"))
        *test = -1;
    if (my_strcmp(av[i], "-n") && my_strcmp(av[i], "-a") && *av[i] == '-')
        *test = -1;
    return (rtn);
}

int set_champ_agr_bis(int ac, char **z, int *i, parm_champ_t *champ)
{
    int test = 1;

    champ->path = "";
    for (; *i < ac && test == 1; (*i)++) {
        if (get_flag_arg(z, *i, champ, &test)) {
            (*i)++;
            continue;
        }
        if (my_strcmp(z[*i], "-n") && my_strcmp(z[*i], "-a") && *z[*i] != '-') {
            champ->path = z[*i];
            test = 2;
        }
    }
    return ((champ->path) ? test : -1);
}

float get_champ_nbr(char **av, int ac)
{
    int nbr = 0;

    for (int index = 1; index < ac && av[index]; index++) {
        if (av[index][0] == '-') {
            index++;
            continue;
        }
        nbr++;
    }
    return (nbr);
}

int look_champ_name(parm_champ_t *champ)
{
    int test = 0;

    for (int index = 0; index < 4; index++) {
        for (int index_bis = index + 1; index_bis < 4; index_bis++)
            test += (champ[index].nbr != -1 && \
            champ[index].nbr == champ[index_bis].nbr) ? 1 : 0;
    }
    return (test);
}

parm_champ_t *set_champ_agr(int ac, char **av)
{
    static parm_champ_t champ[5];
    int n = 1;
    int index_bis = 1;

    for (int index = 0; index != 5; index++) {
        champ[index].nbr = -1;
        champ[index].address = -1;
        champ[index].path = NULL;
    }
    for (int i = 0; i != 4; i++) {
        set_champ_agr_bis(ac, av, &index_bis, &champ[i]);
        if (champ[i].address == -1)
            champ[i].address = ((float)i / get_champ_nbr(av, ac)) * MEM_SIZE;
        if (index_bis >= ac || n == -1)
            break;
    }
    n = (n != -1 && look_champ_name(champ)) ? -1 : n;
    return ((n == -1) ? NULL : champ);
}
