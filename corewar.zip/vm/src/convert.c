/*
** EPITECH PROJECT, 2019
** convect.c
** File description:
** convert bytes file
*/

#include "vm.h"

void reverse_indian(char *ptr, unsigned long size)
{
    long swap;
    char *tmp;

    if (!ptr || !size)
        return;
    tmp = ptr + size - 1;
    while (ptr < tmp) {
        swap = *ptr;
        *ptr = *tmp;
        *tmp = swap;
        ++ptr;
        --tmp;
    }
}

int convert_bytes_to_int(vm_t *vm, int actual_index, int size)
{
    char tmp[4] = {0, 0, 0, 0};
    int tmp_index = 0;
    int i = 0;

    for (int index = size - 1; i < 4 && index > -1; --index, ++i) {
        tmp_index = (actual_index + index) % MEM_SIZE;
        tmp_index += tmp_index < 0 ? MEM_SIZE : 0;
        tmp[3 - i] = vm->arena[tmp_index];
    }
    reverse_indian(tmp, size < 4 ? size : 4);
    return (*(int *) tmp);
}

int convert_bytes_to_int_bis(char *bytes, int size)
{
    char tmp[4] = {0, 0, 0, 0};
    int i = 0;

    for (int index = size - 1; i < 4 && index > -1; --index, ++i)
        tmp[i] = bytes[index];
    return (*(int *) tmp);
}

type_ptr_t init_type_ptr(void)
{
    type_ptr_t new;

    for (int index = 0; index != sizeof(new.reg_bytes); index++)
        new.reg_bytes[index] = 0;
    for (int index = 0; index != sizeof(new.dir_bytes); index++)
        new.dir_bytes[index] = 0;
    for (int index = 0; index != sizeof(new.ind_bytes); index++)
        new.ind_bytes[index] = 0;
    new.src_size = 0;
    new.read_size = 0;
    new.src = NULL;
    return (new);
}
