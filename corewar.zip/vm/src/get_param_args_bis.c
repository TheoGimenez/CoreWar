/*
** EPITECH PROJECT, 2019
** aff.c
** File description:
** displays on the standard output character ASCII of the register
*/

#include "vm.h"

int get_first_arg_bis(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t *ptr_type)
{
    unsigned char arg1 = GET_ARG1(vm->arena[(arena_index + 1) % MEM_SIZE]);

    if (arg1 == 1 && !get_register(vm, &ptr_type[0], \
    arena_index + 2, champ))
        return (0);
    else if (arg1 == 2 && !get_direct(vm, &ptr_type[0], arena_index + 2))
        return (0);
    else
        if (arg1 == 3 && !get_indirect(vm, &ptr_type[0], \
        (int []) {arena_index + 2, arena_index}, REG_SIZE))
            return (0);
    return (1);
}

int get_second_arg_bis(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t * ptr_type)
{
    unsigned char arg2 = GET_ARG2(vm->arena[(arena_index + 1) % MEM_SIZE]);

    if (arg2 == 1 && !get_register(vm, &ptr_type[1], \
    arena_index + 2 + ptr_type[0].read_size, champ))
        return (0);
    else if (arg2 == 2 && !get_direct(vm, &ptr_type[1], \
    arena_index + 2 + ptr_type[0].read_size))
        return (0);
    else
        if (arg2 == 3 && !get_indirect(vm, &ptr_type[1], \
        (int []) {arena_index + 2 + ptr_type[0].read_size, arena_index}, \
        REG_SIZE))
            return (0);
    return (1);
}

int get_third_arg_bis(vm_t *vm, int arena_index, champion_t *champ, \
type_ptr_t * ptr_type)
{
    unsigned char arg3 = GET_ARG3(vm->arena[(arena_index + 1) % MEM_SIZE]);

    if (arg3 == 1 && !get_register(vm, &ptr_type[2], \
    arena_index + 2 + ptr_type[0].read_size + ptr_type[1].read_size, champ))
        return (0);
    else if (arg3 == 2 && !get_direct(vm, &ptr_type[2], \
    arena_index + 2 + ptr_type[0].read_size + ptr_type[1].read_size))
        return (0);
    else
        if (arg3 == 3 && !get_indirect(vm, &ptr_type[2], \
        (int []) {arena_index + 2 + ptr_type[0].read_size + \
        ptr_type[1].read_size, arena_index}, \
        REG_SIZE))
            return (0);
    return (1);
}
