/*
** EPITECH PROJECT, 2019
** get_params.c
** File description:
** get params file
*/

#include "vm.h"

int get_register(vm_t *vm, type_ptr_t *data, int src_size, champion_t *champ)
{
    int register_index = \
    convert_bytes_to_int_bis((char *) (vm->arena + src_size), T_REG) - 1;

    data->src_size = REG_SIZE;
    data->read_size = 1;
    if (register_index >= REG_NUMBER || register_index < 0)
        return (-1);
    data->src = champ->reg[register_index];
    return (1);
}

int get_direct(vm_t *vm, type_ptr_t *data, int src_size)
{
    int src_index = DIR_SIZE - 1;

    data->src_size = DIR_SIZE;
    data->read_size = DIR_SIZE;
    src_size += src_size < 0 ? 0 : MEM_SIZE;
    for (int read_index = DIR_SIZE - 1; read_index > -1 && src_index > -1; \
    --read_index, --src_index)
        data->dir_bytes[src_index] = \
        vm->arena[(read_index + src_size) % MEM_SIZE];
    while (src_index > -1)
        data->dir_bytes[src_index--] = 0;
    data->src = data->dir_bytes;
    return (DIR_SIZE);
}

int get_indirect_scope(vm_t *vm, type_ptr_t *data, int index[], int read_size)
{
    int indirect_index = convert_bytes_to_int_bis(\
    (char *) (vm->arena + index[0]), IND_SIZE) % IDX_MOD;
    int tmp_index = 0;
    int src_index = REG_SIZE - 1;
    data->src_size = read_size;
    data->read_size = IND_SIZE;
    for (int read_index = read_size - 1; read_index > -1 && src_index > -1; \
    --read_index, --src_index) {
        tmp_index = ((index[1] + indirect_index + read_index) % MEM_SIZE);
        tmp_index += (tmp_index < 0) ? MEM_SIZE : 0;
        data->reg_bytes[src_index] = vm->arena[tmp_index];
    }
    while (src_index > -1)
        data->reg_bytes[src_index] = 0;
    data->src = data->reg_bytes;
    return (read_size);
}

int get_indirect(vm_t *vm, type_ptr_t *data, int index[], int read_size)
{
    int indirect_index = convert_bytes_to_int(vm, index[0], IND_SIZE);
    int tmp_index = 0;
    int src_index = REG_SIZE - 1;

    data->src_size = read_size;
    data->read_size = IND_SIZE;
    for (int read_index = read_size - 1; read_index > -1 && src_index > -1; \
    --read_index, --src_index) {
        tmp_index = ((index[1] + indirect_index + read_index) % MEM_SIZE);
        tmp_index += (tmp_index < 0) ? MEM_SIZE : 0;
        data->reg_bytes[src_index] = vm->arena[tmp_index];
    }
    while (src_index > -1)
        data->reg_bytes[src_index] = 0;
    data->src = data->reg_bytes;
    return (read_size);
}
