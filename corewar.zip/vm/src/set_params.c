/*
** EPITECH PROJECT, 2019
** set_params.c
** File description:
** set params file
*/

#include "vm.h"

int set_register(vm_t *vm, type_ptr_t *data, int arena_index, champion_t *champ)
{
    int register_index = convert_bytes_to_int(vm, arena_index, 1);

    if (register_index >= REG_NUMBER || register_index < 0)
        return (0);
    for (int index = 0; index != data->src_size; index++)
        champ->reg[register_index][index] = data->src[index];
    return (1);
}

int set_direct(vm_t *vm, type_ptr_t *data, int arena_index)
{
    for (int index = 0; index != data->src_size; index++)
        vm->arena[(arena_index + index) % MEM_SIZE] = data->src[index];
    return (1);
}

int set_indirect_val_scope(vm_t *vm, type_ptr_t *data, int index[])
{
    int tmp_index = 0;

    for (int index_bis = 0; index_bis != data->src_size; ++index_bis) {
        tmp_index = (((index[0] + index[1]) % IDX_MOD) + index_bis) % MEM_SIZE;
        tmp_index += (tmp_index < 0) ? MEM_SIZE : 0;
        vm->arena[tmp_index] = data->src[index_bis];
    }
    return (1);
}

int set_indirect_scope(vm_t *vm, type_ptr_t *data, int index[])
{
    int indirect_index = convert_bytes_to_int(vm, index[0], IND_SIZE) % IDX_MOD;
    int tmp_index = 0;

    for (int index_bis = 0; index_bis != data->src_size; index_bis++) {
        tmp_index = ((index[1] + indirect_index + index_bis) % MEM_SIZE);
        tmp_index += (tmp_index < 0) ? MEM_SIZE : 0;
        vm->arena[tmp_index] = data->src[index_bis];
    }
    return (1);
}

int set_indirect(vm_t *vm, type_ptr_t *data, int index[])
{
    int indirect_index = convert_bytes_to_int(vm, index[0], IND_SIZE);
    int tmp_index = 0;

    for (int index_bis = 0; index_bis != data->src_size; index_bis++) {
        tmp_index = ((index[1] + indirect_index + index_bis) % MEM_SIZE);
        tmp_index += (tmp_index < 0) ? MEM_SIZE : 0;
        vm->arena[tmp_index] = data->src[index_bis];
    }
    return (1);
}
